package com.example.hackthon_project.retry_transaction;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hackthon_project.entity.RetryTransaction;

@Service
public class RetryService {

    @Autowired
    private RetryTransactionRepository repo;

    @Autowired
    private EmailService emailService;

    private final String NOTIFICATION_EMAIL = "richadixit028@gmail.com"; 

    public void retryPendingTransactions() {
        List<RetryTransaction> transactions = repo.findByStatus("PENDING");

        for (RetryTransaction tx : transactions) {
            if (tx.getNextRetryTime() == null || tx.getNextRetryTime().isBefore(LocalDateTime.now())) {
                boolean success = retryTransaction(tx);
                if (success) {
                    tx.setStatus("SUCCESS");
                    sendSuccessEmail(tx);
                } else {
                    tx.setRetryCount(tx.getRetryCount() + 1);
                    tx.setStatus("RETRYING");
                    tx.setNextRetryTime(calculateNextRetry(tx));
                    sendFailureEmail(tx);

                    if (tx.getRetryCount() >= 5) {
                        createIncident(tx);
                    }
                }
                repo.save(tx);
            }
        }
    }

    private boolean retryTransaction(RetryTransaction tx) {
        try {
            System.out.println("Retrying transaction: " + tx.getTransactionId());
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private LocalDateTime calculateNextRetry(RetryTransaction tx) {
        switch (tx.getRetryStrategy()) {
            case "FIXED":
                return LocalDateTime.now().plusMinutes(5);
            case "EXPONENTIAL":
                return LocalDateTime.now().plusMinutes((long) Math.pow(2, tx.getRetryCount()));
            case "JITTER":
                return LocalDateTime.now().plusMinutes(new Random().nextInt(10));
            default:
                return LocalDateTime.now().plusMinutes(1);
        }
    }

    public List<RetryTransaction> getAllTransactions() {
        return repo.findAll();
    }

    public boolean replayTransaction(Long id) {
        RetryTransaction tx = repo.findById(id).orElse(null);
        if (tx == null) return false;

        tx.setStatus("RETRYING");
        tx.setRetryCount(0);
        tx.setNextRetryTime(LocalDateTime.now());
        repo.save(tx);

        // Send replay notification
        sendReplayEmail(tx);
        return true;
    }

    public RetryTransaction createTestTransaction() {
        RetryTransaction tx = new RetryTransaction();
        tx.setTransactionId("txn123");
        tx.setStatus("PENDING");
        tx.setRetryCount(0);
        tx.setPayload("{ \"data\": \"test\" }");
        tx.setRetryStrategy("FIXED");
        tx.setNextRetryTime(LocalDateTime.now().plusMinutes(5));

        return repo.save(tx);
    }

    private void sendSuccessEmail(RetryTransaction tx) {
        String subject = "✅ Transaction Success: " + tx.getTransactionId();
        String body = String.format("The transaction [%s] has been successfully retried.\n\nPayload: %s", 
                                     tx.getTransactionId(), tx.getPayload());
        emailService.sendNotification(NOTIFICATION_EMAIL, subject, body);
    }

    private void sendFailureEmail(RetryTransaction tx) {
        String subject = "⚠️ Transaction Retry Failed: " + tx.getTransactionId();
        String body = String.format("Transaction [%s] failed to retry. Retry count: %d.\nNext Retry Time: %s", 
                                     tx.getTransactionId(), tx.getRetryCount(), tx.getNextRetryTime());
        emailService.sendNotification(NOTIFICATION_EMAIL, subject, body);
    }

    private void sendReplayEmail(RetryTransaction tx) {
        String subject = "🔁 Manual Replay Initiated: " + tx.getTransactionId();
        String body = String.format("A manual replay has been triggered for transaction [%s].", tx.getTransactionId());
        emailService.sendNotification(NOTIFICATION_EMAIL, subject, body);
    }

    private void createIncident(RetryTransaction tx) {
        // Simulated incident creation
        String subject = "🚨 Incident Created for Failed Transaction: " + tx.getTransactionId();
        String body = String.format("Transaction [%s] has failed %d times.\nPlease investigate immediately.\n\nPayload: %s", 
                                     tx.getTransactionId(), tx.getRetryCount(), tx.getPayload());
        emailService.sendNotification(NOTIFICATION_EMAIL, subject, body);
        System.out.println("Incident created for transaction: " + tx.getTransactionId());
    }
}
