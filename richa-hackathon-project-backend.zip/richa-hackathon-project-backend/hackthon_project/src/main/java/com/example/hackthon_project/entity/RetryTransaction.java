package com.example.hackthon_project.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class RetryTransaction {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private Long id;
	
    private String transactionId;
    private String status; 
    private int retryCount;
    private String payload;
    private LocalDateTime nextRetryTime;
    private String retryStrategy;
    
}

