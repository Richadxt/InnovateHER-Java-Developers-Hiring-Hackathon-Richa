package com.example.hackthon_project.retry_transaction;

import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

@Component
public class RetryJob extends QuartzJobBean {
    @Autowired
    private RetryService retryService;

    @Override
    protected void executeInternal(JobExecutionContext context) {
        retryService.retryPendingTransactions();
    }
}