package com.example.hackthon_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HackthonProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(HackthonProjectApplication.class, args);
	}

}
