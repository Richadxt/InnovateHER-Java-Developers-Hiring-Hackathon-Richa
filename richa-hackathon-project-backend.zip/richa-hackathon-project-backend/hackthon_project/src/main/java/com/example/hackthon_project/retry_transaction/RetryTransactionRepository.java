package com.example.hackthon_project.retry_transaction;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hackthon_project.entity.RetryTransaction;

public interface RetryTransactionRepository extends JpaRepository<RetryTransaction, Long> {
    List<RetryTransaction> findByStatus(String status);
}
