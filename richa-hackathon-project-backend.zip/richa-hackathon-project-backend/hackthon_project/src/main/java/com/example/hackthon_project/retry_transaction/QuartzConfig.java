package com.example.hackthon_project.retry_transaction;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//Job Scheduler
@Configuration
public class QuartzConfig {
 @Bean
 public JobDetail jobDetail() {
     return JobBuilder.newJob(RetryJob.class)
             .withIdentity("retryJob")
             .storeDurably()
             .build();
 }

 @Bean
 public Trigger trigger(JobDetail job) {
     return TriggerBuilder.newTrigger()
             .forJob(job)
             .withIdentity("retryTrigger")
             .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                     .withIntervalInMinutes(1).repeatForever())
             .build();
 }
}

