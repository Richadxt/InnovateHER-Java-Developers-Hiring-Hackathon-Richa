package com.example.hackthon_project.retry_transaction;

import java.time.LocalDateTime;
import java.util.List;

import com.example.hackthon_project.entity.RetryTransaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ReplayController {

    @Autowired
    private RetryService retryService;
    
    @PostMapping("/create")
    public RetryTransaction createTestTransaction() {
    	return retryService.createTestTransaction();
    }

    @GetMapping("/retry/all")
    public ResponseEntity<List<RetryTransaction>> getAll() {
        return ResponseEntity.ok(retryService.getAllTransactions());
    }

    @PostMapping("/replay/{id}")
    public ResponseEntity<?> replay(@PathVariable Long id) {
        boolean replayed = retryService.replayTransaction(id);
        if (!replayed) return ResponseEntity.notFound().build();
        return ResponseEntity.ok("Replay triggered successfully.");
    }
}
